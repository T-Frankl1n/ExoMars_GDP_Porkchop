%% FGKepler_dt algorithm, 'Shooting' for Mars:                      Inputs: Initial Position(r0), Initial Velocity (rdot0), ToF (Delta_t) for elliptical orbits,
%%                                                                  Output: Final Position (r_f), Semi-Major Axis (a), Change in Eccentric Anomaly (Delta_E), F eq, G eq, Orbital mean rate (n)
function [r_f, a, Delta_E,F,G, n] = FGKepler_dt(r0, rdot0, Delta_t, mu) %Change this to jusy 'mu'?
    
    r0_norm = norm(r0);
    rdot0_norm = norm(rdot0);
    
    a = abs(mu / ((2*mu/r0_norm) - rdot0_norm^2));                          % Semi major axis    
    n = sqrt(mu/a^3);                                                       % Mean Rate

    h = cross(r0, rdot0);                                                   % Angular momentum vector
    Delta_E_0 = n*Delta_t;
    sigma0 = dot(r0, rdot0)/sqrt(mu);                                     
    
    Delta_M_Iter = @(Delta_E) Delta_E - (1-r0_norm/a)*sin(Delta_E) - (sigma0/sqrt(a)) * (cos(Delta_E)-1) - Delta_E_0;

    Delta_E = fzero(Delta_M_Iter, Delta_E_0);

    F = 1 - (a/r0_norm)*(1-cos(Delta_E));
    G = Delta_t + sqrt(a^3/mu)*(sin(Delta_E)-Delta_E);                      
    
    r_f = F*r0 + G*rdot0;
end
