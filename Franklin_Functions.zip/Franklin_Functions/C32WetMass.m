%% Final Mass Calculator, :::                                      Inputs: Current Launcher Performance C3 values (C3_values), Current Launcher Wet Mass Delivered (WetMass_values) Baseline C3 values (chosen_x)
%%                                                                 Outputs: C3 to Launched Wet mass plot
function C32WetMass(C3_values, WetMass_values, chosen_x)
    
    if length(C3_values) ~= length(WetMass_values)                              % Check input array lengths
        error('Input arrays must have the same length');
    end
    figure;
    hold on
        plot(C3_values, WetMass_values, '-', 'MarkerFaceColor', 'r', 'DisplayName', 'Launcher Performance Data Points');
        chosen_y = interp1(C3_values, WetMass_values, chosen_x, 'linear');      % Interpolate to find the corresponding x value for the chosen y
        fprintf('For baseline C3 = %.2f, Delivered Wet Mass = %.2f\n', chosen_x, chosen_y);      % Display the chosen baseline C3 value and corresponding Wet Mass delivered
        plot(chosen_x, chosen_y , 'bx', 'MarkerFaceColor', 'b', 'MarkerSize', 8, 'DisplayName', 'Chosen Wet Mass Value');
        
    
        % Assign plot title and axes labels
        xlabel('C3 [km^2s^{-2}]');
        ylabel('Wet Mass [kg]');
        title('C3 vs Wet Mass Falcon 9');
        grid on;
    hold off

end