%% Numerical Integration technique                                  Inputs: time range (t), Column vec [pos,vel], mu of central body)
%%                                                                 Outputs: New state Vector (dYdt)
function [dYdt] = Numerical_Iteration_TwoBodyMotion(t, Y, mu_E)

    Y1 = [Y(1) ; Y(2) ; Y(3)];
    Y2 = [Y(4) ; Y(5) ; Y(6)];
    r_norm = norm(Y1);
    r_hat = Y1./r_norm;

    dY1dt = Y2;
    dY2dt = -(mu_E / (r_norm^2))*r_hat;

    dYdt = [dY1dt ; dY2dt];
end