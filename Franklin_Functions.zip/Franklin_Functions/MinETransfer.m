%% Function from Class Session Slides 2 %%                            Inputs: Initial Position Column Vector (r1), Final Pistition Oclumn Vector (r2), Fast or short Transfer (t_m = +/-1), Gravitational Parameter (mu)
%%                                                                 Outputs: sma (a_min), Eccentricity (e_min), Minimum Duration days (Delta_t_min), Initial Velocity (rdot1)

function [a_min, e_min, Delta_t_min, rdot1] = MinETransfer(r1, r2, t_m, mu)
    c = norm(r2 - r1);

    r1_norm = norm(r1);
    r2_norm = norm(r2);
    r_dprod = dot(r1,r2);
    
    a_min = 0.25*(r1_norm + r2_norm + c);                                   % semi major axis (km)
    DThetac = acos(r_dprod/(r1_norm*r2_norm));                              % Actual trajectory Path 
    DThetas = asin(t_m*sqrt(1-cos(DThetac)^2));                             
    semi_latus_rectum_min = (r1_norm*r2_norm/c)*(1-cos(DThetac));
    e_min = sqrt(1-semi_latus_rectum_min/a_min);
    
    %Computing the time
    Beta_e = 2*asin(sqrt((2*a_min - c)/(2*a_min)));                                                  
    Delta_t_min = sqrt((a_min^3)/mu)*(pi-t_m*(Beta_e-sin(Beta_e))); %/(3600*24); % Days

    %To find rdot1
    p_min = (r1_norm*r2_norm/c)*(1-cos(DThetac));                           % Semi Latus Rectum minimum value
    
    F = 1 - r2_norm/p_min*(1-cos(DThetac));
    G = (r2_norm*r1_norm)/sqrt(mu*p_min)*sin(DThetas);
    
    rdot1 = 1/G * (r2-F*r1);                                               
end