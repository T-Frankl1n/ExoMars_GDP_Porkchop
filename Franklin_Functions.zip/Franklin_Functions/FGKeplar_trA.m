%% FGKepler_trA algorithm:::                                               F&G Solutions for elliptical orbits

% Inputs:
    % 3x1 column vector initial position (r0), 3x1 column vector initial velocity (rdot0), Angle about orbit travelled by transfer (DTheta), mu of central body (mu) 

% Outputs:
    % final position value (r_f)

function r_f = FGKeplar_trA(r0, rdot0, DTheta, mu)
   
    h = cross(r0, rdot0);                                                     % angular momentum vector
    p = norm(h)^2 / mu;                                                          % Semi Latus Rectum                                         
    
    omega0 = dot(r0, rdot0)/sqrt(mu);
    
    r_f_Upper = p*norm(r0);
    r_f_Lower = norm(r0) + (p - norm(r0)) *cos(DTheta) - sqrt(p)*omega0 * sin(DTheta);
    
    r_f = norm(r_f_Upper / r_f_Lower);
    
    F = 1 - (r_f/p).*(1-cos(DTheta));
    G = (r_f*norm(r0))/(sqrt(mu*p)) * sin(DTheta);
    
    r_f = F*r0 + G*rdot0;
    
end