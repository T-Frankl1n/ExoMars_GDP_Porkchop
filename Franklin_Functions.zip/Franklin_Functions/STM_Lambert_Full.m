%% CompleteS full lambert method Using F&G Eqs                      Inputs: Initial Position (r0), Initial Velocity (rdot0), Duration (Delta_t), Gravitational Parameter (mu)
%%                                                                 Outputs: State Transition Matrix (drf_drdot0), Final Position (r_f), G eq, rate of change of G                                                                      
function [drf_drdot0,r_f,G,Gdot] = STM_Lambert_Full(r0, rdot0,Delta_t, mu)  

    [r_f, a, Delta_E,F,G] = FGKepler_dt(r0, rdot0, Delta_t, mu);            

    r_f_norm = norm(r_f);

    Gdot = 1 - (a/r_f_norm)*(1-cos(Delta_E));
    rdot_f = 1/G*(-r0+Gdot*r_f);

    C = a*sqrt(a^3/mu)*(3*sin(Delta_E)-(2+cos(Delta_E))*Delta_E)-a*Delta_t*(1-cos(Delta_E));

    Delta_r = r_f-r0;                                              
    Delta_v = rdot_f - rdot0;                                            

    %STM Output
    drf_drdot0 = norm(r0) / mu*(1-F) * (Delta_r'*rdot0 - Delta_v'*r0) + C/mu *rdot_f'*rdot0+G*eye(3);
end