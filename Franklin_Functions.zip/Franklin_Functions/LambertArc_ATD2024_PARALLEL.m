%% Function from Class Session Slides 2                             Inputs: Initial Position Column Vector (r1), Final Pistition Oclumn Vector (r2), Transfer Duration [Days??] (Delta_t), Fast or short Transfer (t_m = +/-1), Gravitational Parameter (mu)
%%                                                                 Outputs: Initial Velocity (rdot1), Final velocity (rdot2)

function [rdot1_Lambert, rdot2_Lambert] = LambertArc_ATD2024_PARALLEL(r1,r2,Delta_t_target,t_m, mu)       %( , , Delta_t, , )
   
    [~, ~, Delta_t_min, rdot1] = MinETransfer(r1, r2, t_m, mu);             %[a_min, e_min, Delta_t_min, rdot1_Lambert]    

    % Begin Loop
    %Defining the number of differential correction steps
    nIterations = 10;                                                       % Iteration number until reaching the desired solution
    exitLoop = false;                                                       % Early exit flag
    for iTer = 1:nIterations
        if exitLoop
            break;                                                          %exit loop if flag is met
        end
        
        Lambda = iTer / nIterations;
        DT = Lambda*Delta_t_target + (1-Lambda)*Delta_t_min;
        
        Error = 999;
        numMaxIter = 25;
        NumIter = 0;
        
        while (Error>1e-3) && (NumIter<numMaxIter)

            [r2_f,~,~,~,~,~] = FGKepler_dt(r1,rdot1,DT,mu);                 % Propagate over DT to find final position [r2f, a, Delta_E,F,G, n]
            [drf_drdot0,~] = STM_Lambert_Full(r1,rdot1,DT,mu);
            
            Error_Calc = r2-r2_f;
            Error = abs(norm(Error_Calc));
            
            Delta_r_f_corr = inv(drf_drdot0)*(Error_Calc)';                 % Compute the correction (r2 = r_M)         
            rdot1_Lambert = rdot1 + Delta_r_f_corr';
            
            %Set new values for iteration
            rdot1 = rdot1_Lambert;

            [r2_f,~,~,~,~,~] = FGKepler_dt(r1,rdot1,DT,mu);                 % [r_f, a, Delta_E,F,G, n]

            [~,~,G,Gdot] = STM_Lambert_Full(r1,rdot1,DT,mu);                % [drf_drdot0,r_f, Gdot] = STM_Lambert_Full(r0, rdot0,Delta_t, mu)
            rdot2_Lambert = 1/G * (-r1+Gdot*r2_f);      
            
            
            % Safety check for the sma in case orbit goes hyperbolic. this case would 
            sma_checker = mu/2/(mu/norm(r1)-norm(rdot1)^2 /2);
            if sma_checker < 0
                exitLoop = true;
                break;
                % warning('numMaxIter Issue: The shooting method did not converge.')
                rdot1 = [NaN NaN NaN];
                rdot2 = [NaN NaN NaN];
                return 
             end
             if NumIter == numMaxIter
                exitLoop = true;
                break
                % warning('numMaxIter Issue: The shooting method did not converge')
                rdot1 = [NaN NaN NaN];
                rdot2 = [NaN NaN NaN];
                return 
             end
             
             NumIter = NumIter+1;

            % fprintf('Iteration %.f \n rdot1 Value: %.5e \n rdot2 Value: %.5e \n Error: %.5e \n \n',NumIter,norm(rdot1_Lambert), norm(rdot2_Lambert), Error)
             
        end
    % fprintf('Required Tolerence Met...\n')    

    end
end

